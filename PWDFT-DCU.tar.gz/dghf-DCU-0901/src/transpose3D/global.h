
//typedef float doublereal;
typedef double doublereal;


