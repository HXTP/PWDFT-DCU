cd external/lbfgs
make cleanall 
cd ../rqrcp
make cleanall  
cd ../../src
make cleanall 
cd ../examples
make cleanall 
